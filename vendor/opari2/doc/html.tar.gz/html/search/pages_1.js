var searchData=
[
  ['ctc_2dstring_20decoding',['CTC-String Decoding',['../CTC_STRING.html',1,'index']]]
];
