var searchData=
[
  ['ctc_5fomp_5ftokens',['CTC_OMP_TOKENS',['../pomp2__region__info_8h.html#ac86b4fc4c04b1049b788a9fec71dc8fc',1,'pomp2_region_info.h']]],
  ['ctc_2dstring_20decoding',['CTC-String Decoding',['../CTC_STRING.html',1,'index']]],
  ['ctc_5fuser_5fregion_5ftokens',['CTC_USER_REGION_TOKENS',['../pomp2__user__region__info_8h.html#a93fefda49d7492bf924809e8b6b6ee77',1,'pomp2_user_region_info.h']]],
  ['ctcstring2regioninfo',['ctcString2RegionInfo',['../pomp2__region__info_8h.html#ada8fce980385bdc6598a889bc2ba7892',1,'pomp2_region_info.h']]],
  ['ctcstring2userregioninfo',['ctcString2UserRegionInfo',['../pomp2__user__region__info_8h.html#adf68daa6bcbb49e313189a50c692217a',1,'pomp2_user_region_info.h']]]
];
