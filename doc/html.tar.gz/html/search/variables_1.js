var searchData=
[
  ['base',['base',['../structSCOREP__Metric__Plugin__MetricProperties.html#a946859e0e1fa6bca9e42f8eee3e8022f',1,'SCOREP_Metric_Plugin_MetricProperties::base()'],['../structSCOREP__Metric__Properties.html#ad536799cc8bed9c092d6381d45c9a0dc',1,'SCOREP_Metric_Properties::base()']]]
];
