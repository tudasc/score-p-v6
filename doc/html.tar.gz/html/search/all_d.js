var searchData=
[
  ['type_20definitions_20and_20enums_20used_20in_20score_2dp',['type definitions and enums used in Score-P',['../group__Public.html',1,'']]],
  ['timestamp',['timestamp',['../structSCOREP__MetricTimeValuePair.html#aaaf11b68a483378fe20e163f789a543a',1,'SCOREP_MetricTimeValuePair']]]
];
