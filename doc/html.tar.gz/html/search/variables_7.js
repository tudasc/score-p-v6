var searchData=
[
  ['init',['init',['../structSCOREP__SubstratePluginInfo.html#ab3b377e52787222cf05fc6e99353e0f6',1,'SCOREP_SubstratePluginInfo']]],
  ['init_5fmpp',['init_mpp',['../structSCOREP__SubstratePluginInfo.html#a25f18d03f528f84731a403cdc3801a42',1,'SCOREP_SubstratePluginInfo']]],
  ['initialize',['initialize',['../structSCOREP__Metric__Plugin__Info.html#aeeaad74fc73eab3cba16e49c2476ee5a',1,'SCOREP_Metric_Plugin_Info']]]
];
