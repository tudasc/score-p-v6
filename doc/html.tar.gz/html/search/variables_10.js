var searchData=
[
  ['write_5fdata',['write_data',['../structSCOREP__SubstratePluginInfo.html#a57f5e2bafd3c28149670d5801054bc66',1,'SCOREP_SubstratePluginInfo']]]
];
