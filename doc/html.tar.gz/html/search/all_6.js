var searchData=
[
  ['get_5fall_5fvalues',['get_all_values',['../structSCOREP__Metric__Plugin__Info.html#a45a52a4753ab3c601981041552fd9c5e',1,'SCOREP_Metric_Plugin_Info']]],
  ['get_5fcurrent_5fvalue',['get_current_value',['../structSCOREP__Metric__Plugin__Info.html#aeb1db6b96675dac81bfbb6effa81366f',1,'SCOREP_Metric_Plugin_Info']]],
  ['get_5fevent_5ffunctions',['get_event_functions',['../structSCOREP__SubstratePluginInfo.html#aca1e33bb5df50b3b9fc60994452ea09e',1,'SCOREP_SubstratePluginInfo']]],
  ['get_5fevent_5finfo',['get_event_info',['../structSCOREP__Metric__Plugin__Info.html#a087f24f475a628a1ac92b35824393fe8',1,'SCOREP_Metric_Plugin_Info']]],
  ['get_5foptional_5fvalue',['get_optional_value',['../structSCOREP__Metric__Plugin__Info.html#a9040874b7af59b330559472623c3a428',1,'SCOREP_Metric_Plugin_Info']]],
  ['get_5frequirement',['get_requirement',['../structSCOREP__SubstratePluginInfo.html#a01c64f9532e723084907f527f6e89586',1,'SCOREP_SubstratePluginInfo']]],
  ['getting_20started',['Getting Started',['../quickstart.html',1,'']]]
];
